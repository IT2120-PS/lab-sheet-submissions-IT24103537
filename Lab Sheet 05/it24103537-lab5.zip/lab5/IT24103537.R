setwd("C:\\Users\\Asus\\OneDrive\\Desktop\\New folder (3)")
Delivery_Times <- read.table("Exercise - lab 05.txt",header=TRUE)
head(Delivery_Times)
X <- Delivery_Times[[1]] 
breaks <- seq(20,70,length.out = 10)
hist(X,breaks = breaks,right = FALSE,main = "Histogram of delivery times(9 right-open classes)",
     xlab = "Delivery Time",ylab = "Frequency")
h <- hist(X,breaks = breaks,right = FALSE,plot = FALSE)
cum_freq <- c(0,cumsum(h$counts))
upper_bounds <- breaks
plot(upper_bounds,cum_freq,type="o",xlab = "Delivery time",ylab = "Cumulative frequency",
     main = "ogive(Cumulative Frequency polygon)")
grid()
